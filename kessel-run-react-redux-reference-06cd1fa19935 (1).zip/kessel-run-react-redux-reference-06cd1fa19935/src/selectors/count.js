/* @flow */
import type { State } from '../types'

export default function(state: State): number {
  return state.count
}
