/* @flow */

export type Position = {
  vertical: 'up' | 'down',
  horizontal: 'left' | 'right'
}
