/* @flow */

export type State = {
  count: number
}
